package ubb.scs.map.functionalinterface;

@FunctionalInterface
interface AritmeticExpression {

    double calculate(double a, double b);
    // others default or static methods
}
