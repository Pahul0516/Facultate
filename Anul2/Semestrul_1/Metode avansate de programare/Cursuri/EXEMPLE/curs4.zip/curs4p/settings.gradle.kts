rootProject.name = "curs4p"

